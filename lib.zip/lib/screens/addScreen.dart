import 'package:flutter/material.dart';

class addScreen extends StatefulWidget {
  const addScreen({super.key});

  @override
  State<addScreen> createState() => _addScreenState();
}

class _addScreenState extends State<addScreen> {
  @override
  Widget build(BuildContext context) {

    Map data = ModalRoute.of(context)?.settings.arguments as Map;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Add ToDo"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            IconButton(
              icon: const Icon(Icons.save), 
              onPressed: (){
                Navigator.pop(context);
              }
            ),
            Text("You already have ${data["no"]} tasks"),
          ],
        )
      ),
    );
  }
}